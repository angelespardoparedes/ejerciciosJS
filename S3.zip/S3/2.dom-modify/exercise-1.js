/**Inserta dinamicamente en un html un div vacio con javascript. */

let nuevoDiv = document.createElement("div");


// Agrega el nuevo div al final del body (puedes ajustar esto según tus necesidades)
document.body.appendChild(nuevoDiv);