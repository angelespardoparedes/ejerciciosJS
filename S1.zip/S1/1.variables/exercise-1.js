// Ej 1 Crea una variable llamada carName, asignale el valor Volvo a ella.
let carName= Volvo; 
