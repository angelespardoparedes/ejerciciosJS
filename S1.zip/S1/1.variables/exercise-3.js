//Ej 3 Crea una variable llamada x con el valor 5 y otra y con el valor 10. Crea una tercera variable z y asignale el valor de x + y.

let x=5;
let y=10;
let z=x+y; 