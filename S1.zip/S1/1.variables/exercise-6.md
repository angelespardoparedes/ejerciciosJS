Dado el siguiente javascript, imprime con un ``console.log`` la suma del precio de ambos juguetes.

```js
const toy1 = {name: 'Buss myYear', price: 19};
const toy2 = {name: 'Rallo mcKing', price: 29};
```