/* Dado el siguiente javascript, cambia el valor de la propiedad ``age`` a 25.

```js
const character = {name: 'Jack Sparrow', age: 10};
```*/

const character = {name: 'Jack Sparrow', age: 10};
character.age = 25; 
console.log(character)

