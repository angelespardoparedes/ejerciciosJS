Crea una variable llamada x, asignale el valor 50 a ella.
