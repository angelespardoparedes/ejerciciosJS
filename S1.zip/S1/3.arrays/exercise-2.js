/**Cambia el primer elemento de cars a "Ford"

```js
const cars = ['Saab', 'Volvo', 'BMW'];
``` */

const cars = ['Saab', 'Volvo', 'BMW'];

cars[0]='Ford';

console.log(cars);