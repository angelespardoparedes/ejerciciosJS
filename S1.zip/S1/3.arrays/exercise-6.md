Elimina el segundo elemento del array y muestra el array por consola.
```js
const RickAndMortyCharacters = ["Rick", "Beth", "Jerry", "Morty", "Summer", "Lapiz Lopez"];
```