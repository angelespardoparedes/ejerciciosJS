/** Crea un bucle for que vaya desde 0 a 9 y muestralo por consola solo cuando el resto del numero dividido entre 2 sea 0.*/

let x=0; 
while(x<10){
 if(x%2===0){console.log(x);}   
 x++; 

}
