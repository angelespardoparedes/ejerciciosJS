/**Crea un bucle for que vaya desde 0 a 9 y muestralo por consola. */
let x=0; 
while(x<10){
    
 console.log(x);
 x++; 

}