//Usa el correcto operador de asignación que resultará en ``x = 50``, teniendo dos variables ``y = 10`` y ``z = 5``.

let y=10;
let z=5;

let x=10*5; 

console.log(x); 