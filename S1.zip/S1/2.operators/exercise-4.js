//Usa el correcto operador de asignación que resultará en ``x = 15``, teniendo dos variables ``y = 10`` y ``z = 5``.
let y=10;
let z=5;

let x=y+z;

console.log(x);