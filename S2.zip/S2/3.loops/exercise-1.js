/**Usa un bucle forof para recorrer todos los destinos del array. Imprime en un console log sus valores.
```js
const placesToTravel = ['Japon', 'Venecia', 'Murcia', 'Santander', 'Filipinas', 'Madagascar']
``` */
const placesToTravel = ['Japon', 'Venecia', 'Murcia', 'Santander', 'Filipinas', 'Madagascar'];

for(let places of placesToTravel){
    console.log(places);
}